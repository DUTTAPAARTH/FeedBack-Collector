import React, { useState, useEffect } from 'react';
import './App.css';
import FeedbackForm from './components/FeedbackForm';
import FeedbackList from './components/FeedbackList';

function App() {
  const [feedbacks, setFeedbacks] = useState([]);
  const [sortBy, setSortBy] = useState('newest');
  const [filterCategory, setFilterCategory] = useState('all');
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

  // Fetch feedback on mount
  useEffect(() => {
    fetchFeedback();
  }, []);

  const fetchFeedback = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/feedback`);
      if (!response.ok) throw new Error('Failed to fetch feedback');
      const data = await response.json();
      setFeedbacks(data);
      setError(null);
    } catch (err) {
      console.error('Error fetching feedback:', err);
      setError('Failed to load feedback. Using local storage.');
      // Fallback to localStorage
      const stored = localStorage.getItem('feedbacks');
      if (stored) {
        setFeedbacks(JSON.parse(stored));
      }
    } finally {
      setLoading(false);
    }
  };

  const addFeedback = async (feedback) => {
    try {
      const response = await fetch(`${API_URL}/feedback`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(feedback),
      });

      if (!response.ok) throw new Error('Failed to add feedback');
      const newFeedback = await response.json();
      const updated = [newFeedback, ...feedbacks];
      setFeedbacks(updated);
      localStorage.setItem('feedbacks', JSON.stringify(updated));
      setError(null);
    } catch (err) {
      console.error('Error adding feedback:', err);
      // Fallback: add to local state and localStorage
      const newFeedback = {
        id: Date.now().toString(),
        ...feedback,
        likes: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const updated = [newFeedback, ...feedbacks];
      setFeedbacks(updated);
      localStorage.setItem('feedbacks', JSON.stringify(updated));
    }
  };

  const deleteFeedback = async (id) => {
    try {
      const response = await fetch(`${API_URL}/feedback/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Failed to delete feedback');
      const updated = feedbacks.filter((f) => f.id !== id);
      setFeedbacks(updated);
      localStorage.setItem('feedbacks', JSON.stringify(updated));
      setError(null);
    } catch (err) {
      console.error('Error deleting feedback:', err);
      // Fallback
      const updated = feedbacks.filter((f) => f.id !== id);
      setFeedbacks(updated);
      localStorage.setItem('feedbacks', JSON.stringify(updated));
    }
  };

  const likeFeedback = async (id) => {
    try {
      const response = await fetch(`${API_URL}/feedback/${id}/like`, {
        method: 'POST',
      });

      if (!response.ok) throw new Error('Failed to like feedback');
      const updated = feedbacks.map((f) =>
        f.id === id ? { ...f, likes: f.likes + 1 } : f
      );
      setFeedbacks(updated);
      localStorage.setItem('feedbacks', JSON.stringify(updated));
      setError(null);
    } catch (err) {
      console.error('Error liking feedback:', err);
      // Fallback
      const updated = feedbacks.map((f) =>
        f.id === id ? { ...f, likes: f.likes + 1 } : f
      );
      setFeedbacks(updated);
      localStorage.setItem('feedbacks', JSON.stringify(updated));
    }
  };

  const startEdit = (id, text) => {
    setEditingId(id);
    setEditText(text);
  };

  const saveEdit = async (id) => {
    if (!editText.trim()) {
      alert('Feedback cannot be empty');
      return;
    }

    try {
      const response = await fetch(`${API_URL}/feedback/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: editText }),
      });

      if (!response.ok) throw new Error('Failed to update feedback');
      const updated = feedbacks.map((f) =>
        f.id === id ? { ...f, message: editText, updatedAt: new Date().toISOString() } : f
      );
      setFeedbacks(updated);
      localStorage.setItem('feedbacks', JSON.stringify(updated));
      setEditingId(null);
      setEditText('');
      setError(null);
    } catch (err) {
      console.error('Error updating feedback:', err);
      // Fallback
      const updated = feedbacks.map((f) =>
        f.id === id ? { ...f, message: editText, updatedAt: new Date().toISOString() } : f
      );
      setFeedbacks(updated);
      localStorage.setItem('feedbacks', JSON.stringify(updated));
      setEditingId(null);
      setEditText('');
    }
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditText('');
  };

  // Sort and filter
  const getSortedAndFilteredFeedback = () => {
    let filtered = feedbacks;

    // Filter by category
    if (filterCategory !== 'all') {
      filtered = filtered.filter((f) => f.category === filterCategory);
    }

    // Sort
    const sorted = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt) - new Date(a.createdAt);
        case 'oldest':
          return new Date(a.createdAt) - new Date(b.createdAt);
        case 'mostLiked':
          return b.likes - a.likes;
        case 'leastLiked':
          return a.likes - b.likes;
        default:
          return 0;
      }
    });

    return sorted;
  };

  const categories = ['all', ...new Set(feedbacks.map((f) => f.category || 'general'))];

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <h1 className="app-title">✨ Feedback Collector</h1>
          <p className="app-subtitle">Share your thoughts and see what others think</p>
        </div>
      </header>

      <main className="app-main">
        <div className="container">
          {error && <div className="error-banner">{error}</div>}

          <FeedbackForm onSubmit={addFeedback} />

          <div className="controls">
            <div className="sort-controls">
              <label htmlFor="sort">Sort by:</label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="select-input"
              >
                <option value="newest">Newest</option>
                <option value="oldest">Oldest</option>
                <option value="mostLiked">Most Liked</option>
                <option value="leastLiked">Least Liked</option>
              </select>
            </div>

            <div className="filter-controls">
              <label htmlFor="filter">Category:</label>
              <select
                id="filter"
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="select-input"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </option>
                ))}
              </select>
            </div>

            <div className="feedback-count">
              {feedbacks.length > 0 && <span>{feedbacks.length} feedback{feedbacks.length !== 1 ? 's' : ''}</span>}
            </div>
          </div>

          {loading ? (
            <div className="loading">Loading feedback...</div>
          ) : getSortedAndFilteredFeedback().length === 0 ? (
            <div className="empty-state">
              <p className="empty-icon">📭</p>
              <p className="empty-text">
                {feedbacks.length === 0
                  ? 'No feedback yet. Be the first to share!'
                  : 'No feedback matches your filters.'}
              </p>
            </div>
          ) : (
            <FeedbackList
              feedbacks={getSortedAndFilteredFeedback()}
              onDelete={deleteFeedback}
              onLike={likeFeedback}
              onEdit={startEdit}
              onSaveEdit={saveEdit}
              onCancelEdit={cancelEdit}
              editingId={editingId}
              editText={editText}
              setEditText={setEditText}
            />
          )}
        </div>
      </main>

      <footer className="app-footer">
        <p>&copy; 2024 Feedback Collector. Built with React & Express.</p>
      </footer>
    </div>
  );
}

export default App;
